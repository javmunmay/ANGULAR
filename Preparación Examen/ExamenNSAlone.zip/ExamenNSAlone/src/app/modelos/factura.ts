export interface Factura {

    id:number,
    numero:string,
    id_cliente:number,
    fecha:Date,
    precio:number,
    tipo_iva:number
    


}
