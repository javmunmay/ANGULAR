export interface DetalleFactura {
    id:number,
    idFactura:number,
    cantidad:number,
    concepto:string,
    precio:number,
    tipo_iva:number,
    iva:number,
    total:number
}
